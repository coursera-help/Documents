import sys
import string
for line in sys.stdin:
	line = line.strip()
	year, month, maxTemp, minTemp, frostDays, rainfall, sunshine=line.split("\t")
	rainfall_inches=float(rainfall)/25.4
	print "\t".join([year, month, maxTemp, minTemp,frostDays, str(rainfall_inches), sunshine])
