import sys
import string
for line in sys.stdin:
	line = line.strip()
	#print("hey", line)
	obs, distTaxi, distMkt, distHosp, carpet, builtup, parking, cityCat, rainfall, houseprice = line.split("\t")
	#print(obs)
	#print(disttaxi)
	rainfall_inches=float(rainfall) / 25.4
	houseprice_dollar=float(houseprice) / 60
	#print("hey", houseprice_dollar)
	print "\t".join([obs, distTaxi, distMkt, distHosp, carpet, builtup, parking, cityCat, str(rainfall_inches), str(houseprice_dollar)])

	
    
    
