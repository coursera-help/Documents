# -*- coding: utf-8 -*-
"""
Created on Wed Feb 28 21:51:51 2018

@author: Sanmoy
"""

import bs4 as bs 
import urllib.request
import pandas as pd
from newspaper import Article
import pickle
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.feature_extraction.text import TfidfTransformer
from sklearn.feature_extraction.text import TfidfVectorizer

url = 'https://timesofindia.indiatimes.com/2018/2/1/archivelist/year-2018,month-2,starttime-43132.cms'
sauce = urllib.request.urlopen(url).read()
soup = bs.BeautifulSoup(sauce, 'lxml')

tables = []
for link in soup.find_all('table'):
	tables.append(link)
	
links = tables[2].find_all('a')

urllist = []
for link in links:
	urllist.append(link.get('href'))

# print(urllist[10])
# url2 = 'https://timesofindia.indiatimes.com'+urllist[10]
# article = Article(url2)
# article.download()
# article.parse()
# print(article.text)

articles_list = []
try:

	for i in range(0, len(urllist)):
		newurl = 'https://timesofindia.indiatimes.com'+urllist[i]
		article = Article(newurl)
		article.download()
		article.parse()
		articles_list.append(article.title)
		articles_list.append(article.text)	

except Exception as e:
	pass

pickle.dump(articles_list, open( "article.p", "wb" ) )

articles_list = pickle.load(open('article.p', 'rb'))

print(len(articles_list))

for article in articles_list:
	print('##########################')
	print(article)




count_vectorizer = CountVectorizer(min_df=1)
term_freq_matrix = count_vectorizer.fit_transform(articles_list)
# print("Vocabulary:", count_vectorizer.vocabulary_)



tfidf = TfidfTransformer(norm="l2")
tfidf.fit(term_freq_matrix)

tf_idf_matrix = tfidf.transform(term_freq_matrix)
print(tf_idf_matrix.todense())



tfidf_vectorizer = TfidfVectorizer(min_df = 1)
tfidf_matrix = tfidf_vectorizer.fit_transform(articles_list)

print(tfidf_matrix.todense())
print(tfidf_matrix.shape)