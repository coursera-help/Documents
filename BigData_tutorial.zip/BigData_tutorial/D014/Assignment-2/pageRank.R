library(igraph)
A <- matrix(c(0,0.5,1,0,
              0.33,0,0,0.5,
              0.33,0,0,0.5,
              0.33,0.5,0,0),nrow  = 4)
#Transpose Matrix
A = t(A)

#Creating graph
g <- graph_from_adjacency_matrix(t(A),weighted = T)

#Rank
rank<-page_rank(g, directed = TRUE, damping = 0.25)

rank$vector

