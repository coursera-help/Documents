
# 
# 1. [TFIDF] :
# @vector = pass in a vector of documents  
TFIDF <- function(vector) {
    # tf 
    news_corpus  <- Corpus( VectorSource(vector) )
    control_list <- list(removePunctuation = TRUE, stopwords = TRUE, tolower = TRUE)
    tf <- TermDocumentMatrix(news_corpus, control = control_list) %>% as.matrix()

    # idf
    idf <- log( ncol(tf) / ( 1 + rowSums(tf != 0) ) ) %>% diag()
    return( crossprod(tf, idf) )
}

# tf-idf matrix using news' title 
news_tf_idf <- TFIDF(news$title)

# 2. [Cosine] :
# distance between two vectors
Cosine <- function(x, y) {
    similarity <- sum(x * y) / ( sqrt( sum(y ^ 2) ) * sqrt( sum(x ^ 2) ) )

    # given the cosine value, use acos to convert back to degrees
    # acos returns the radian, multiply it by 180 and divide by pi to obtain degrees
    return( acos(similarity) * 180 / pi )
}

# 3. calculate pair-wise distance matrix 
pr_DB$set_entry( FUN = Cosine, names = c("Cosine") )
d1 <- dist(news_tf_idf, method = "Cosine")
pr_DB$delete_entry("Cosine")

# 4. heirachical clustering 
cluster1 <- hclust(d1, method = "ward.D")
plot(cluster1)
rect.hclust(cluster1, 17)